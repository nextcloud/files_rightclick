OC.L10N.register(
  "files_rightclick", {
    "Open folder" : "Open map",
    "Open file" : "Open bestand",
    "Open in new tab" : "In nieuw tabblad openen",
    "Edit file" : "Bestand bewerken",
    "Read PDF" : "PDF openen",
    "See picture" : "Afbeelding bekijken",
    "Open in Gallery" : "Openen in galerij",
    "Play" : "Afspelen",
    "Play/Pause" : "Afspelen/Pauzeren",
    "Stop playback" : "Afspelen stoppen",
    "Watch" : "Video bekijken",
    "Share folder" : "Map delen",
    "Share file" : "Bestand delen",
    "Select" : "Selecteren",
    "Unselect" : "Selectie opheffen",
    "Get WebDAV link" : "Toon WebDAV link",
    "Copied !": "Gekopieerd !"
  },
  "nplurals=2; plural=(n > 1);"
);
