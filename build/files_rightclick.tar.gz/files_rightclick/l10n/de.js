OC.L10N.register(
  "files_rightclick", {
    "Open folder" : "Ordner öffnen",
    "Open file" : "Datei öffnen",
    "Open in new tab" : "In neuem Tab öffnen",
    "Edit file" : "Datei bearbeiten",
    "Read PDF" : "PDF öffnen",
    "See picture" : "Bild ansehen",
    "Open in Gallery" : "Öffnen in Galerie",
    "Play" : "Starte Wiedergabe",
    "Stop playback" : "Stoppe Wiedergabe",
    "Watch" : "Video ansehen",
    "Share folder" : "Ordner teilen",
    "Share file" : "Datei teilen",
    "Select" : "Markieren",
    "Unselect" : "Markierung aufheben",
  },
  "nplurals=2; plural=(n > 1);"
);
