OC.L10N.register(
  "files_rightclick", {
    "Open folder" : "Apri cartella",
    "Open file" : "Apri file",
    "Open in new tab" : "Apri in una nuova scheda",
    "Edit file" : "Modifica file",
    "Read PDF" : "Leggi PDF",
    "See picture" : "Apri immagine",
    "Open in Gallery" : "Apri nella galleria immagini",
    "Play" : "Esegui",
    "Play/Pause" : "Esegui/Pausa",
    "Stop playback" : "Ferma esecuzione",
    "Watch" : "Apri video",
    "Share folder" : "Condividi cartella",
    "Share file" : "Condividi file",
    "Select" : "Seleziona",
    "Unselect" : "Deseleziona",
    "Get WebDAV link" : "Crea link WebDAV",
    "Copied !": "Copiato !"
  },
  "nplurals=2; plural=(n > 1);"
);
