OC.L10N.register(
  "files_rightclick", {
    "Open folder" : "Åpne mappe",
    "Open file" : "Åpne fil",
    "Open in new tab" : "Åpne i ny fane",
    "Edit file" : "Editere fil",
    "Read PDF" : "Les PDF",
    "See picture" : "Se bilde",
    "Open in Gallery" : "Åpne i galleri",
    "Play" : "Spille av",
    "Play/Pause" : "Spille av/Pause",
    "Stop playback" : "Stop avspilling",
    "Watch" : "Se film",
    "Share folder" : "Del mappe",
    "Share file" : "Del fil",
    "Select" : "Velge",
    "Unselect" : "Velge bort",
    "Get WebDAV link" : "Får WebDAV lenke",
    "Copied !": "Kopiert !"
  },
  "nplurals=2; plural=(n > 1);"
);
